// ===== LOAD CART =====
function loadCart() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let cartContainer = document.getElementById('cartItems');
  let total = 0;

  cartContainer.innerHTML = '';

  if (cart.length === 0) {
    cartContainer.innerHTML = '<p>Your cart is empty.</p>';
    document.getElementById('subtotal').textContent = '$0';
    document.getElementById('total').textContent = '$0';
    return;
  }

  cart.forEach(function(item, index) {
    total += item.price * item.qty;

    let itemHTML = `
      <div class="cart-item">
        <img src="${item.img}" alt="${item.name}"/>
        <div class="item-details">
          <h3>${item.name}</h3>
          <p>Size: ${item.size}</p>
          <p>$${item.price}</p>
          <div class="qty-controls">
            <button onclick="decreaseQty(${index})">-</button>
            <span>${item.qty}</span>
            <button onclick="increaseQty(${index})">+</button>
          </div>
        </div>
        <button onclick="removeItem(${index})">Remove</button>
      </div>
    `;
    cartContainer.innerHTML += itemHTML;
  });

  document.getElementById('subtotal').textContent = '$' + total;
  document.getElementById('total').textContent = '$' + total;
}

// ===== INCREASE QUANTITY =====
function increaseQty(index) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart[index].qty++;
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
}

// ===== DECREASE QUANTITY =====
function decreaseQty(index) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  if (cart[index].qty > 1) {
    cart[index].qty--;
  } else {
    cart.splice(index, 1);
  }
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
}

// ===== REMOVE ITEM =====
function removeItem(index) {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  loadCart();
}

// ===== UPDATE CART COUNTER =====
function updateCartCounter() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

// ===== PLACE ORDER =====
function placeOrder() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  if (cart.length === 0) {
    alert('Your cart is empty!');
    return;
  }

  let name = document.getElementById('name').value;
  let email = document.getElementById('email').value;
  let address = document.getElementById('address').value;

  if (!name || !email || !address) {
    alert('Please fill in all fields!');
    return;
  }

  let orderDetails = 'Order placed successfully!\n\n';
  orderDetails += 'Customer: ' + name + '\n';
  orderDetails += 'Email: ' + email + '\n';
  orderDetails += 'Address: ' + address + '\n\n';
  orderDetails += 'Items:\n';

  let total = 0;
  cart.forEach(function(item) {
    orderDetails += '- ' + item.name + ' (Size: ' + item.size + ') x' + item.qty + ' = $' + (item.price * item.qty) + '\n';
    total += item.price * item.qty;
  });

  orderDetails += '\nTotal: $' + total;

  alert(orderDetails);

  localStorage.removeItem('cart');
  updateCartCounter();
  loadCart();
}

// Page load pe cart load karo
window.addEventListener('load', function() {
  loadCart();
  updateCartCounter();
});