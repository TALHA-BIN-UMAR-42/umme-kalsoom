// ===== SIZE SELECTION =====
function selectSize(element) {
  let allSizes = element.parentElement.querySelectorAll('span');
  allSizes.forEach(function(size) {
    size.classList.remove('selected');
  });
  element.classList.add('selected');
}

// ===== PRODUCTS DATA =====
let allProducts = [
  { name: 'AirMax Pro', price: 120, img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Speed Boost', price: 110, img: 'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Urban Kick', price: 100, img: 'https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Street Runner', price: 95, img: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Classic Force', price: 90, img: 'https://images.unsplash.com/photo-1605348532760-6753d2c43329?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Elite Performance', price: 85, img: 'https://images.unsplash.com/photo-1612521534857-a3a0fb5ae0cc?w=400&h=300&fit=crop', category: 'men' },
  { name: 'Glam Walker', price: 95, img: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Elegance Stride', price: 105, img: 'https://images.unsplash.com/photo-1595777712802-26ab0b5b413e?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Comfort Queen', price: 98, img: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Urban Queen', price: 92, img: 'https://images.unsplash.com/photo-1551431009-381d36ac3a14?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Chic Pulse', price: 88, img: 'https://images.unsplash.com/photo-1562183125-813820ae6fe3?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Style Icon', price: 100, img: 'https://images.unsplash.com/photo-1487927917289-8c61e80ec84e?w=400&h=300&fit=crop', category: 'women' },
  { name: 'Mini Kick', price: 60, img: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=400&h=300&fit=crop', category: 'kids' },
  { name: 'Junior Jump', price: 55, img: 'https://images.unsplash.com/photo-1503066211613-c17ebc9daef0?w=400&h=300&fit=crop', category: 'kids' },
  { name: 'Little Runner', price: 50, img: 'https://images.unsplash.com/photo-1470819312497-1cc03f2bc154?w=400&h=300&fit=crop', category: 'kids' },
  { name: 'Play Time', price: 58, img: 'https://images.unsplash.com/photo-1520639888713-7851133b1ed0?w=400&h=300&fit=crop', category: 'kids' },
  { name: 'Fun Run', price: 45, img: 'https://images.unsplash.com/photo-1471286174890-9c112ffca5b4?w=400&h=300&fit=crop', category: 'kids' },
  { name: 'Star Kick', price: 40, img: 'https://images.unsplash.com/photo-1491553895911-0055eca6402d?w=400&h=300&fit=crop', category: 'kids' }
];

// ===== LOAD FEATURED PRODUCTS =====
function loadFeaturedProducts() {
  let grid = document.getElementById('featuredGrid');
  if (!grid) return;
  
  grid.innerHTML = '';
  let featured = allProducts.slice(0, 5);
  
  featured.forEach(function(product) {
    let card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
      <img src="${product.img}" alt="${product.name}"/>
      <h3>${product.name}</h3>
      <p class="price">$${product.price}</p>
      <div class="size-options">
        <p class="size-label">Size:</p>
        <div class="sizes">
          <span onclick="selectSize(this)">40</span>
          <span onclick="selectSize(this)">41</span>
          <span onclick="selectSize(this)">42</span>
          <span onclick="selectSize(this)">43</span>
        </div>
      </div>
      <button onclick="addToCart(this)">Add to Cart</button>
      <button onclick="addToWishlist(this)">❤️ Wishlist</button>
    `;
    grid.appendChild(card);
  });
}

// ===== UPDATE CART COUNTER =====
function updateCartCounter() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

// ===== ADD TO CART =====
function addToCart(btn) {
  let card = btn.closest('.card');
  let name = card.querySelector('h3').textContent;
  let price = parseInt(card.querySelector('.price').textContent.replace('$', ''));
  let img = card.querySelector('img').src;
  let selectedSize = card.querySelector('.sizes .selected');
  let size = selectedSize ? selectedSize.textContent : 'N/A';

  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  let exists = cart.find(function(item) { return item.name === name && item.size === size; });

  if (exists) {
    exists.qty++;
  } else {
    cart.push({ name, price, img, qty: 1, size });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCounter();
  window.location.href = 'cart.html';
}

// ===== ADD TO WISHLIST =====
function addToWishlist(btn) {
  let card = btn.closest('.card');
  let name = card.querySelector('h3').textContent;
  let price = card.querySelector('.price').textContent;
  let img = card.querySelector('img').src;

  let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

  let exists = wishlist.find(function(item) {
    return item.name === name;
  });

  if (exists) {
    return;
  }

  wishlist.push({ name, price, img });
  localStorage.setItem('wishlist', JSON.stringify(wishlist));

  btn.textContent = '❤️ Added!';
  btn.classList.add('added');

  window.location.href = 'wishlist.html';
}

// ===== SHOP NOW BUTTON =====
document.querySelector('.hero button').addEventListener('click', function() {
  document.querySelector('.featured').scrollIntoView({ behavior: 'smooth' });
});

// ===== UPDATE ACCOUNT NAME =====
function updateAccountName() {
  let profile = JSON.parse(localStorage.getItem('userProfile')) || { name: '' };
  document.getElementById('account-name').textContent = profile.name ? ' ' + profile.name : '';
}

// Page load pe cart counter update karo
window.addEventListener('load', function() {
  updateCartCounter();
  updateAccountName();
  loadFeaturedProducts();
});