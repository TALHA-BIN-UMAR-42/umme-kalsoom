// ===== CART COUNTER =====
let cartCount = 0;

function addToCart() {
  cartCount++;
  document.getElementById('cart-count').textContent = cartCount;
  alert('✅ Shoe added to cart!');
}


// ===== SEND MESSAGE FUNCTION =====
// Jab "Send Message" button click ho
function sendMessage() {

  // Form se values lo
  let name = document.getElementById('name').value;
  let email = document.getElementById('email').value;
  let subject = document.getElementById('subject').value;
  let message = document.getElementById('message').value;


  // ===== VALIDATION =====
  // Agar koi field khali ho to error do

  if (name === '') {
    alert('⚠️ Please enter your name!');
    return;
  }

  if (email === '') {
    alert('⚠️ Please enter your email!');
    return;
  }

  if (subject === '') {
    alert('⚠️ Please enter a subject!');
    return;
  }

  if (message === '') {
    alert('⚠️ Please enter your message!');
    return;
  }


  // ===== SUCCESS =====
  // Agar sab fields bhari hain

  alert('✅ Message sent successfully! We will get back to you soon.');

  // Form clear karo
  document.getElementById('name').value = '';
  document.getElementById('email').value = '';
  document.getElementById('subject').value = '';
  document.getElementById('message').value = '';

}


// ===== INPUT FOCUS EFFECT =====
// Jab input pe click karo to highlight ho

const inputs = document.querySelectorAll('input, textarea');

inputs.forEach(function(input) {
  input.addEventListener('focus', function() {
    this.style.borderColor = '#f0a500';  // Golden border
  });

  input.addEventListener('blur', function() {
    this.style.borderColor = '#333333';  // Wapas normal
  });
});