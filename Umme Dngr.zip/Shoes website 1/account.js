function loadProfile() {
  let profile = JSON.parse(localStorage.getItem('userProfile')) || {
    name: '',
    email: '',
    phone: '',
    address: ''
  };

  document.getElementById('name').value = profile.name;
  document.getElementById('email').value = profile.email;
  document.getElementById('phone').value = profile.phone;
  document.getElementById('address').value = profile.address;
  updateAccountName();
  updateCartCounter();
}

function saveProfile() {
  let profile = {
    name: document.getElementById('name').value,
    email: document.getElementById('email').value,
    phone: document.getElementById('phone').value,
    address: document.getElementById('address').value
  };

  localStorage.setItem('userProfile', JSON.stringify(profile));
  updateAccountName();
  window.location.href = 'products.html';
}

function deleteAccount() {
  let confirm = window.confirm('Are you sure you want to delete your account? This action cannot be undone.');
  
  if (confirm) {
    localStorage.removeItem('userProfile');
    updateAccountName();
    alert('Account deleted successfully!');
    window.location.href = 'home.html';
  }
}

function updateAccountName() {
  let profile = JSON.parse(localStorage.getItem('userProfile')) || { name: '' };
  document.getElementById('account-name').textContent = profile.name ? ' ' + profile.name : '';
}

function updateCartCounter() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

window.addEventListener('load', loadProfile);