// ===== UPDATE CART COUNTER =====
function updateCartCounter() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

// ===== SIZE SELECTION =====
function selectSize(element) {
  let allSizes = element.parentElement.querySelectorAll('span');
  allSizes.forEach(function(size) {
    size.classList.remove('selected');
  });
  element.classList.add('selected');
}

// ===== FILTER FUNCTION =====
function filterProducts(category) {
  const cards = document.querySelectorAll('.card');

  cards.forEach(function(card) {
    if (category === 'all') {
      card.classList.remove('hidden');
    } else if (card.dataset.category === category) {
      card.classList.remove('hidden');
    } else {
      card.classList.add('hidden');
    }
  });

  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(function(btn) {
    btn.classList.remove('active');
  });

  event.target.classList.add('active');
}
// ===== WISHLIST FUNCTION =====
function addToWishlist(btn) {
  // Card ka data lo
  let card = btn.closest('.card');
  let name = card.querySelector('h3').textContent;
  let price = card.querySelector('.price').textContent;
  let img = card.querySelector('img').src;

  // Wishlist localStorage se lo
  let wishlist = JSON.parse(localStorage.getItem('wishlist')) || [];

  // Check karo already add hai ya nahi
  let exists = wishlist.find(function(item) {
    return item.name === name;
  });

  if (exists) {
    // already in wishlist, skip.
    return;
  }

  // Wishlist mein add karo
  wishlist.push({ name, price, img });
  localStorage.setItem('wishlist', JSON.stringify(wishlist));

  // Button update karo
  btn.textContent = '❤️ Added!';
  btn.classList.add('added');
}
function addToCart(btn) {
  let card = btn.closest('.card');
  let name = card.querySelector('h3').textContent;
  let price = parseInt(card.querySelector('.price').textContent.replace('$', ''));
  let img = card.querySelector('img').src;
  let selectedSize = card.querySelector('.sizes .selected');
  let size = selectedSize ? selectedSize.textContent : 'N/A';

  let cart = JSON.parse(localStorage.getItem('cart')) || [];

  let exists = cart.find(function(item) { return item.name === name && item.size === size; });

  if (exists) {
    exists.qty++;
  } else {
    cart.push({ name, price, img, qty: 1, size });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCounter();
  window.location.href = 'cart.html';
}

// Page load pe cart counter update karo
window.addEventListener('load', function() {
  updateCartCounter();
});