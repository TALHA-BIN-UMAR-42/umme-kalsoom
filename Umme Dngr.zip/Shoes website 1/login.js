// ===== SIGN UP FORM HANDLING =====
document.getElementById('signupForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  const confirmPassword = document.getElementById('confirmPassword').value;

  if (password !== confirmPassword) {
    alert('Passwords do not match!');
    return;
  }

  if (password.length < 6) {
    alert('Password must be at least 6 characters long!');
    return;
  }

  // Check if user already exists
  let users = JSON.parse(localStorage.getItem('users')) || [];
  const existingUser = users.find(user => user.email === email);
  if (existingUser) {
    alert('User with this email already exists!');
    return;
  }

  // Add new user
  users.push({ name, email, password });
  localStorage.setItem('users', JSON.stringify(users));

  alert('Sign up successful! Welcome to The Kick Hub.');
  // Redirect to home or login
  window.location.href = 'home.html';
});

// ===== UPDATE CART COUNTER =====
function updateCartCounter() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

// Page load pe counter update karo
window.addEventListener('load', function() {
  updateCartCounter();
});