// ===== CART COUNTER =====
let cartCount = 0;

function addToCart() {
  cartCount++;
  document.getElementById('cart-count').textContent = cartCount;
  alert('✅ Shoe added to cart!');
}


// ===== STATS ANIMATION =====
// Jab page load ho to numbers count karte hue aayein

function animateCount(element, target) {
  let count = 0;
  let speed = 30; // Kitni jaldi count kare

  let timer = setInterval(function() {
    count += Math.ceil(target / 100);

    // Agar count target se zyada ho jaye to rok do
    if (count >= target) {
      count = target;
      clearInterval(timer);
    }

    element.textContent = count + '+';

  }, speed);
}


// ===== PAGE LOAD PE ANIMATION CHALAO =====
window.addEventListener('load', function() {

  const statNumbers = document.querySelectorAll('.stat-box h3');

  // Har stat box ka number animate karo
  statNumbers.forEach(function(stat) {

    // Text se number nikalo (+ hata ke)
    let targetNumber = parseInt(stat.textContent);

    // Animation shuru karo
    animateCount(stat, targetNumber);

  });

});