// ===== UPDATE CART COUNTER =====
function updateCartCount() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let count = cart.reduce(function(sum, item) { return sum + item.qty; }, 0);
  document.getElementById('cart-count').textContent = count;
}

// ===== ORDER SUMMARY ON PAGE =====
function loadOrderSummary() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let container = document.getElementById('orderItemsContainer');
  let totalEl = document.getElementById('orderTotal');

  if (!container || !totalEl) return;

  container.innerHTML = '';
  let cartTotal = 0;

  if (cart.length === 0) {
    container.innerHTML = '<p>Your cart is empty. Add items from products page first.</p>';
    totalEl.textContent = '$0';
    return;
  }

  cart.forEach(function(item) {
    let row = document.createElement('div');
    row.className = 'summary-item';
    row.innerHTML = `
      <span>${item.name} (Size: ${item.size}) x ${item.qty}</span>
      <span>$${item.price * item.qty}</span>
    `;
    container.appendChild(row);
    cartTotal += item.price * item.qty;
  });

  totalEl.textContent = '$' + cartTotal;
}

// ===== REMOVE EMPTY CART MESSAGE =====
function clearCart() {
  localStorage.removeItem('cart');
  updateCartCount();
  loadOrderSummary();
}

// ===== PLACE ORDER FUNCTION =====
function placeOrder() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  if (cart.length === 0) {
    alert('🛒 Your cart is empty. Please add items before placing an order.');
    return;
  }

  let fullname = document.getElementById('fullname').value.trim();
  let phone = document.getElementById('phone').value.trim();
  let email = document.getElementById('email').value.trim();
  let address = document.getElementById('address').value.trim();
  let city = document.getElementById('city').value.trim();
  let zip = document.getElementById('zip').value.trim();
  let payment = document.querySelector('input[name="payment"]:checked').value;

  if (!fullname || !phone || !email || !address || !city || !zip) {
    alert('⚠️ Please fill in all fields before placing order.');
    return;
  }

  let total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  let summary = `🎉 Order Confirmed!\n\nName: ${fullname}\nPhone: ${phone}\nEmail: ${email}\nAddress: ${address}, ${city}, ${zip}\nPayment: ${payment.toUpperCase()}\n\nTotal: $${total}\n\nItems:\n`;
  cart.forEach(item => {
    summary += `- ${item.name} (Size: ${item.size}) x ${item.qty} = $${item.price * item.qty}\n`;
  });

  alert(summary);

  // Clear after order
  clearCart();

  document.getElementById('fullname').value = '';
  document.getElementById('phone').value = '';
  document.getElementById('email').value = '';
  document.getElementById('address').value = '';
  document.getElementById('city').value = '';
  document.getElementById('zip').value = '';

  // Redirect to home or confirmation page if needed
  window.location.href = 'home.html';
}

// ===== INPUT FOCUS EFFECT =====
const inputs = document.querySelectorAll('input[type="text"], input[type="email"]');

inputs.forEach(function(input) {
  input.addEventListener('focus', function() {
    this.style.borderColor = '#f0a500';
  });

  input.addEventListener('blur', function() {
    this.style.borderColor = '#333333';
  });
});

// ===== UPDATE ACCOUNT NAME =====
function updateAccountName() {
  let profile = JSON.parse(localStorage.getItem('userProfile')) || { name: '' };
  document.getElementById('account-name').textContent = profile.name ? ' ' + profile.name : '';
}

window.addEventListener('load', function() {
  updateCartCount();
  updateAccountName();
  loadOrderSummary();
});